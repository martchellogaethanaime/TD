def caesar_encrypt(message, shift=3):
    encrypted = ""
    for c in message:
        if c.isupper():    # lettres majuscules
            encrypted += chr((ord(c) - 65 + shift) % 26 + 65)
        elif c.islower():  # lettres minuscules
            encrypted += chr((ord(c) - 97 + shift) % 26 + 97)
        elif c.isdigit():  # chiffres
            encrypted += chr((ord(c) - 48 + shift) % 10 + 48)
        else:              # les autres caractères restent inchangés
            encrypted += c
    return encrypted

def caesar_decrypt(cipher, shift=3):
    return caesar_encrypt(cipher, -shift)  # décalage négatif pour déchiffrement

message = "Bonjour 123!"
shift = 4
cipher   = caesar_encrypt(message, shift)
decipher = caesar_decrypt(cipher, shift)
print("Message original :", message)
print("Message chiffré  :", cipher)
print("Message déchiffré:", decipher)