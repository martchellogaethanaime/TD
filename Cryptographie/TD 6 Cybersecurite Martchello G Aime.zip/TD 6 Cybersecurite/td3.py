import string
import random
import math

def generate_key(length, charset=string.printable.strip()):
    """Génère une clé aléatoire de longueur donnée."""
    return ''.join(random.choice(charset) for _ in range(length))

def xor_cipher(message, key):
    """Chiffre ou déchiffre par XOR (opération symétrique)."""
    return ''.join(
        chr(ord(m) ^ ord(k)) for m, k in zip(message, key)
    )

def calculate_entropy(key, alphabet):
    L = len(set(alphabet))
    N = len(key)
    return N * math.log2(L) if L > 0 else 0

# Test
message = "HELLO"
charset = string.ascii_letters + string.digits + string.punctuation
key     = generate_key(len(message), charset)

cipher   = xor_cipher(message, key)
original = xor_cipher(cipher, key)   # même clé = déchiffrement

print(f"Message   : {message}")
print(f"Clé       : {key}")
print(f"Chiffré   : {repr(cipher)}")
print(f"Déchiffré : {original}")

# Calcul entropie
entropy = calculate_entropy(key, charset)
print(f"\nEntropie de la clé : {entropy:.2f} bits")
# → sécurisé si entropy >= 128 bits