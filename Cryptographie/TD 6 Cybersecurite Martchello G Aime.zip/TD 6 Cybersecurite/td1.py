import string
import random
import math

# Ensembles de caractères
char_sets = {
    "ascii_letters":   string.ascii_letters,
    "ascii_lowercase": string.ascii_lowercase,
    "ascii_uppercase": string.ascii_uppercase,
    "digits":          string.digits,
    "hexdigits":       string.hexdigits,
    "octdigits":       string.octdigits,
    "punctuation":     string.punctuation,
    "printable":       string.printable,
    "whitespace":      string.whitespace
}

def generate_key(char_set, length=16):
    return ''.join(random.choice(char_set) for _ in range(length))

def calculate_entropy(key, alphabet=None):
    if alphabet is None:
        alphabet = set(key)
    L = len(alphabet)
    N = len(key)
    return N * math.log2(L) if L > 0 else 0

key_length = 16
for name, chars in char_sets.items():
    key = generate_key(chars, key_length)
    entropy = calculate_entropy(key, alphabet=set(chars))
    print(f"{name:15}: {key} | Entropie ≈ {entropy:.2f} bits")