import string
import math
import matplotlib.pyplot as plt

# Ensembles de caractères à comparer
char_sets = {
    "lowercase (26)" : string.ascii_lowercase,
    "letters (52)"   : string.ascii_letters,
    "digits (10)"    : string.digits,
    "all (94)"       : string.ascii_letters + string.digits + string.punctuation
}

def calculate_entropy(N, L):
    return N * math.log2(L) if L > 0 else 0

lengths = [4, 8, 16, 24, 32]

# Affichage des valeurs
print(f"{'Longueur':>10}", end='')
for name in char_sets:
    print(f"  {name:>16}", end='')
print()

for N in lengths:
    print(f"{N:>10}", end='')
    for name, chars in char_sets.items():
        H = calculate_entropy(N, len(chars))
        print(f"  {H:>13.2f} b", end='')
    print()

# Tracé du graphique
plt.figure(figsize=(10, 6))

colors = ['#1D9E75', '#534AB7', '#BA7517', '#D85A30']
for (name, chars), color in zip(char_sets.items(), colors):
    entropies = [calculate_entropy(N, len(chars)) for N in lengths]
    plt.plot(lengths, entropies, marker='o', label=name, color=color)

plt.axhline(y=128, color='red', linestyle='--', alpha=0.7,
            label='Seuil recommandé (128 bits)')
plt.xlabel('Longueur de la clé (caractères)')
plt.ylabel('Entropie (bits)')
plt.title("Entropie vs Longueur de clé selon l'alphabet")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('entropie_graphique.png', dpi=150)
plt.show()